<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Transaksi extends CI_Controller{

    function __construct(){
        parent::__construct();      
        $this->load->model('Transaksi_model', 'transaksi');
        $this->load->helper('url');

    }

    function index(){
        $data['transaksi'] = $this->transaksi->tampil_data()->result();
        $this->load->view('transaksi/index',$data);
    }

    function tambah(){
        $this->load->view('transaksi/input_transaksi');
    }

    function tambah_aksi(){
        $id_user = $this->input->post('id_user');
        $tanggal_transaksi = $this->input->post('tanggal_transaksi');
        $invest_saham = $this->input->post('invest_saham');
        $invest_pasar_uang = $this->input->post('invest_pasar_uang');
        $invest_pendapatan_tetap = $this->input->post('invest_pendapatan_tetap');
        $invest_campuran = $this->input->post('invest_campuran');

        $data = array(
            'id_user' => $id_user,
            'tanggal_transaksi' => $tanggal_transaksi,
            'invest_saham' => $invest_saham,
            'invest_pasar_uang' => $invest_pasar_uang,
            'invest_pendapatan_tetap' => $invest_pendapatan_tetap,
            'invest_campuran' => $invest_campuran,

        );

        $this->session->set_flashdata('msg-success', 'Successful Insert Data.');
        $this->transaksi->input_data($data,'transaksi');
        redirect('transaksi/index');
    }

    function hapus($id){
        $where = array('id' => $id);

        $this->session->set_flashdata('msg-success', 'Successful Deleted Data.');
        $this->transaksi->hapus_data($where,'transaksi');
        redirect('transaksi/index');
    }

    function edit($id){
        $where = array('transaksi.id' => $id);
        $data['transaksi'] = $this->transaksi->edit_data($where,'transaksi')->result();
        $this->load->view('transaksi/edit_transaksi',$data);
    }

    function update(){
        $id = $this->input->post('id');
        $id_user = $this->input->post('id_user');
        $tanggal_transaksi = $this->input->post('tanggal_transaksi');
        $invest_saham = $this->input->post('invest_saham');
        $invest_pasar_uang = $this->input->post('invest_pasar_uang');
        $invest_pendapatan_tetap = $this->input->post('invest_pendapatan_tetap');
        $invest_campuran = $this->input->post('invest_campuran');

        $data = array(
            'id_user' => $id_user,
            'tanggal_transaksi' => $tanggal_transaksi,
            'invest_saham' => $invest_saham,
            'invest_pasar_uang' => $invest_pasar_uang,
            'invest_pendapatan_tetap' => $invest_pendapatan_tetap,
            'invest_campuran' => $invest_campuran,
        );

        $where = array(
            'id' => $id
        );

        $this->session->set_flashdata('msg-success', 'Successful Edit Data.');
        $this->transaksi->update_data($where,$data,'transaksi');
        redirect('transaksi/index');
    }
}
