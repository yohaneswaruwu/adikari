
<!DOCTYPE html>
<html lang="en">

<?php $this->load->view('template/header') ?>

<?php if ($this->session->flashdata('success')): ?>
  <div class="alert alert-success" role="alert">
    <?php echo $this->session->flashdata('success');?>
  </div> 
<?php endif;?>   
<?php if ($this->session->flashdata('delete')): ?>
  <div class="alert alert-danger" role="alert">
    <?php echo $this->session->flashdata('delete');?>
  </div> 
<?php endif;?> 
<div class="card shadow-sm mb-4">
  <div class="card-header py-3">
    <a class="btn btn-primary float-right" href="<?php echo base_url();?>transaksi/tambah"><i class="fa fa-plus"></i>Tambah</a>
  </div>                        
  <div class="card-body">
    <div class="table-responsive">
      <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
        <thead>
          <tr>
            <th style="width: 30px;">No.</th>
            <th>ID User</th>
            <th>Nama Nasabah</th>
            <th>Tanggal Transaksi</th>
            <th>Invest Saham</th>
            <th>Invest Pasar Uang</th>    
            <th>Invest Pendapatan Tetap</th>    
            <th>Invest Campuran</th>    
            <th style="width: 70px;">Aksi</th>                  
          </tr>
        </thead>                  
        <tbody>
          <?php $no=1;
          foreach ($transaksi as $datatransaksi): ?>
            <tr>
              <td style="text-align: center;"><?php echo $no++;?></td>
              <td><?php echo $datatransaksi->id;?></td>
              <td><?php echo $datatransaksi->nama;?></td>
              <td><?php echo $datatransaksi->tanggal_transaksi;?></td>
              <td><?php echo $datatransaksi->invest_saham;?></td>
              <td><?php echo $datatransaksi->invest_pasar_uang;?></td>
              <td><?php echo $datatransaksi->invest_pendapatan_tetap;?></td>
              <td><?php echo $datatransaksi->invest_campuran;?></td>
              <td style="text-align: center;">
                <a href="<?php echo base_url();?>transaksi/edit/<?php echo $datatransaksi->id_transaksi;?>" class="btn btn-primary btn-sm"><i class="fa fa-edit"></i></a>
                <a href="<?php echo base_url();?>transaksi/hapus/<?php echo $datatransaksi->id_transaksi;?>" onclick="return confirm('Apakah anda yakin dihapus?')" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></a>
              </td>                      
            </tr>
          <?php endforeach;?>
        </tbody>
      </table>
    </div>
  </div>
</div>
</div>             


<script src="<?php echo base_url(); ?>/assets/jquery/jquery.slim.min.js"></script>
<script src="<?php echo base_url(); ?>/assets/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="<?php echo base_url(); ?>/assets/datatable/datatables.min.js"></script>
<script>
  $(document).ready(function () {
    $('#dataTable').DataTable();
  });
</script>
</body>
</html>
