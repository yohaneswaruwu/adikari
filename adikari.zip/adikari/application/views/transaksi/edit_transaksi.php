
<!DOCTYPE html>
<html lang="en">

<?php $this->load->view('template/header') ?>


<?php if ($this->session->flashdata('success')): ?>
  <div class="alert alert-success" role="alert">
    <?php echo $this->session->flashdata('success');?>. <u><a href="<?php echo base_url();?>transaksi" style="color: #155724">Lihat data Transaksi</a></u>
  </div>               
<?php endif;?>
<?php foreach($transaksi as $transaksi){ ?>
<form method="POST" action="<?php echo base_url();?>transaksi/update">     
<input type="hidden" name="id" value="<?php echo $transaksi->id_transaksi;?>">                   
  <div class="card shadow-sm mb-4">
    <div class="card-header py-3">
      <h6 class="m-0 font-weight-bold text-primary">Edit Data Transaksi </h6>
    </div>
    <div class="card-body">
      <label for="nama">ID User</label>
      <div class="form-group">
        <!-- <input type="text" class="form-control form-control-user" placeholder="ID User" name="id_user" required=""> -->
        <select name="id_user" id="heard" class="form-control" required>
          <option value="<?php echo $transaksi->id;?>"><?php echo $transaksi->id.' - '.$transaksi->nama;?></option>
          <?php 
          $query = $this->db->query("SELECT * from auth");
          foreach ($query->result_array() as $row) {?>
            <option value="<?php echo $row['id']; ?>"><?php echo $row['id']." - ".$row['nama']; ?></option>
          <?php }?>
        </select>

      </div>
      <label for="nim">Tanggal Transaksi</label>
      <div class="form-group">
        <input type="date" class="form-control form-control-user" placeholder="Tanggal Transaksi" name="tanggal_transaksi" required="" value="<?php echo $transaksi->tanggal_transaksi;?>">
      </div>
      <label for="fakultas">Invest Saham</label>
      <div class="form-group">
        <input type="number" class="form-control form-control-user" placeholder="Invest Saham" name="invest_saham" required="" value="<?php echo $transaksi->invest_saham;?>">
      </div>
      <label for="jurusan">Invest Pasar Uang</label>
      <div class="form-group">
        <input type="number" class="form-control form-control-user" placeholder="Invest Pasar Uang" name="invest_pasar_uang" required="" value="<?php echo $transaksi->invest_pasar_uang;?>">
      </div>
      <label for="jurusan">Invest Pendapatan Tetap</label>
      <div class="form-group">
        <input type="number" class="form-control form-control-user" placeholder="Invest Pendapatan Tetap" name="invest_pendapatan_tetap" required="" value="<?php echo $transaksi->invest_pendapatan_tetap;?>">
      </div>
      <label for="jurusan">Invest Campuran</label>
      <div class="form-group">
        <input type="number" class="form-control form-control-user" placeholder="Invest Campuran" name="invest_campuran" required="" value="<?php echo $transaksi->invest_campuran;?>">
      </div>
    </div>
    <div class="card-footer">
      <button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> Simpan Data</button>
      <a href="<?php echo base_url();?>" class="btn btn-default">Batal</a>
    </div>
  </div>
</form>   
<?php } ?>
</div>                   

<script src="<?php echo base_url(); ?>/assets/jquery/jquery.slim.min.js"></script>
<script src="<?php echo base_url(); ?>/assets/bootstrap/js/bootstrap.bundle.min.js"></script>
</body>
</html>
