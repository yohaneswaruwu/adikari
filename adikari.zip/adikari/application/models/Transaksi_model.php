<?php 

class Transaksi_model extends CI_Model{
    function tampil_data(){
        $this->db->select('transaksi.id AS id_transaksi, auth.id, nama, tanggal_transaksi, invest_saham, invest_pasar_uang, invest_pendapatan_tetap, invest_campuran');
        $this->db->join ( 'auth', 'auth.id = transaksi.id_user');
        // $this->db->join ( 'nasabah', 'nasabah.id = transaksi.id_user');
        $this->db->order_by('transaksi.id','asc');
        return $this->db->get('transaksi');
    }

    function input_data($data,$table){
        $this->db->insert($table,$data);
    }

    function hapus_data($where,$table){
        $this->db->where($where);
        $this->db->delete($table);
    }

    function edit_data($where,$table){     
        $this->db->select('transaksi.id AS id_transaksi, auth.id, nama, tanggal_transaksi, invest_saham, invest_pasar_uang, invest_pendapatan_tetap, invest_campuran');
        $this->db->join ( 'auth', 'auth.id = transaksi.id_user');
        $this->db->order_by('transaksi.id','asc');
        return $this->db->get_where($table,$where);
    }

    function update_data($where,$data,$table){
        $this->db->where($where);
        $this->db->update($table,$data);
    }   
}

?>
