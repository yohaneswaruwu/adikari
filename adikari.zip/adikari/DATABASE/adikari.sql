-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Mar 28, 2022 at 10:53 AM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `adikari`
--

-- --------------------------------------------------------

--
-- Table structure for table `auth`
--

CREATE TABLE `auth` (
  `id` char(5) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `auth`
--

INSERT INTO `auth` (`id`, `nama`, `username`, `password`) VALUES
('43195', 'Minami Nitta', 'minami', '12341'),
('47757', 'Tokazaki', 'maya', '12342'),
('50961', 'Narusawa Rikka', 'rikka', '12343'),
('51883', 'Shibuya Rin', 'shiburin', '12344'),
('64798', 'Jougasaki Mika', 'mika', '12345');

-- --------------------------------------------------------

--
-- Table structure for table `nasabah`
--

CREATE TABLE `nasabah` (
  `id` char(5) NOT NULL,
  `jenis_kelamin` varchar(10) NOT NULL,
  `usia` int(3) NOT NULL,
  `pekerjaan` varchar(255) NOT NULL,
  `pendapatan` varchar(255) NOT NULL,
  `sumber_pendapatan` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `nasabah`
--

INSERT INTO `nasabah` (`id`, `jenis_kelamin`, `usia`, `pekerjaan`, `pendapatan`, `sumber_pendapatan`) VALUES
('43195', 'Laki-laki', 17, 'Pelajar', '< 10 Juta', 'Dari Orang Tua/Anak'),
('47757', 'Perempuan', 23, 'Swasta', '10 Juta - 50 Juta', 'Gaji'),
('50961', 'Perempuan', 55, 'IRT', '10 Juta - 50 Juta', 'Keuntungan Bisnis'),
('51883', 'Perempuan', 47, 'Lainnya', '50 Juta - 100 Juta', 'Gaji'),
('64798', 'Perempuan', 66, 'Swasta', '10 Juta - 50 Juta', 'Gaji');

-- --------------------------------------------------------

--
-- Table structure for table `transaksi`
--

CREATE TABLE `transaksi` (
  `id` int(11) NOT NULL,
  `id_user` char(5) NOT NULL,
  `tanggal_transaksi` date NOT NULL,
  `invest_saham` int(15) NOT NULL,
  `invest_pasar_uang` int(15) NOT NULL,
  `invest_pendapatan_tetap` int(15) NOT NULL,
  `invest_campuran` int(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `transaksi`
--

INSERT INTO `transaksi` (`id`, `id_user`, `tanggal_transaksi`, `invest_saham`, `invest_pasar_uang`, `invest_pendapatan_tetap`, `invest_campuran`) VALUES
(1, '43195', '2021-10-01', 280000, 50000, 170000, 0),
(2, '43195', '2021-10-02', 280000, 50000, 170000, 0),
(3, '43195', '2021-10-03', 280000, 50000, 170000, 0),
(4, '47757', '2021-10-01', 100000, 0, 5300000, 0),
(5, '47757', '2021-10-02', 100000, 0, 7300000, 0),
(6, '47757', '2021-10-03', 100000, 0, 7800000, 0),
(7, '50961', '2021-10-01', 700000, 100000, 200000, 0),
(8, '50961', '2021-10-02', 1700000, 100000, 200000, 0),
(9, '50961', '2021-10-03', 1700000, 100000, 200000, 0),
(10, '51883', '2021-10-01', 50000, 10000, 40000, 0),
(11, '51883', '2021-10-02', 50000, 10000, 40000, 0),
(12, '51883', '2021-10-03', 50000, 10000, 40000, 0),
(13, '64798', '2021-10-01', 160000, 62060, 150000, 0),
(14, '64798', '2021-10-02', 160000, 101760, 150000, 0),
(15, '64798', '2021-10-03', 160000, 113560, 150000, 0),
(22, '47757', '2022-03-28', 11, 22, 33, 44);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `auth`
--
ALTER TABLE `auth`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `nasabah`
--
ALTER TABLE `nasabah`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `transaksi`
--
ALTER TABLE `transaksi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
