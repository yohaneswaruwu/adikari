# CRUD Simpel Menggunakan Codeigniter Framework (Bahasa Indonesia)

## Tutorial 

Clone dengan menggunakan :

```sh
git clone https://github.com/indrijunanda/crud-codeigniter-simple.git
```

atau kamu bisa langsung download dalam bentuk **.zip**

### Database 

buatlah database dengan nama

```
ci_crud
```

dan import file sql yang ada pada folder *mysql file*


-------------------
### Cheers Up!

*Happy Developing and Learning* 💪



Regards 😁😁
